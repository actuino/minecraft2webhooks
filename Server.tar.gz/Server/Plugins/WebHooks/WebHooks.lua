PLUGIN = nil
pos = {ecran = {-4,78,14,-11,78,7}}
colors = {1,2,3,4,5,6,8,9,10,11,14,15,16}

-- r1 g2 b4
liste = {}
function Initialize(Plugin)
	Plugin:SetName("WebHooks")
	Plugin:SetVersion(1)

	-- Hooks
	--
	cPluginManager:AddHook(cPluginManager.HOOK_PLAYER_PLACED_BLOCK, OnPlayerPlacedBlock);
	cPluginManager:AddHook(cPluginManager.HOOK_PLAYER_BROKEN_BLOCK, OnPlayerBrokenBlock);
	PLUGIN = Plugin -- NOTE: only needed if you want OnDisable() to use GetName() or something like that

	
	
	
	-- Command Bindings


	
	cPluginManager.BindCommand("/unicorn", "core.help", charge, "")
	cPluginManager.BindCommand("/rnd", "core.help", setrnd, "")
	cPluginManager.BindCommand("/savescreen", "core.help", savescreen, "")
	cPluginManager.BindCommand("/charge", "core.help", chargescreen, "")
	cPluginManager.BindCommand("/address", "core.help", address, "")
	cPluginManager.BindCommand("/changeaddress", "core.help", changeaddress, "")

	fileh = assert(io.open("address.txt","r"))
	address = fileh:read"*a"
	fileh:close()
	LOG("Initialised " .. Plugin:GetName() .. " v." .. Plugin:GetVersion())
	return true
end

function OnDisable()
	LOG(PLUGIN:GetName() .. " is shutting down...")
end

function OnPlayerBrokenBlock(Player, BlockX, BlockY, BlockZ, BlockFace, BlockType, BlockMeta)
	charge({},Player)


end


function OnPlayerPlacedBlock(Player, BlockX, BlockY, BlockZ, BlockType, BlockMeta)
	charge({},Player)
end

function changeaddress(Split, Player)
local World = Player:GetWorld()
	if Split[2] then
		fileh = assert(io.open("address.txt","w"))
		address = Split[2]
		fileh:write(address)
		fileh:close()
		World:BroadcastChat("address has been changed to: "..address)
	else
		World:BroadcastChat("Usage : /changeaddress 192.168.7.3")
	end
	
	
	return true
end


function address(Split, Player)
	local World = Player:GetWorld()
	World:BroadcastChat("actual address is: ".. address)
	
	
	return true
end


function chargescreen(Split, Player)
	
	file = assert(io.open("screens/"..Split[2]..".json",'r'))
	
	--screen = cJson:Parse(file)
	fichier = file:read "*a"
	
	file:close()
	local World = Player:GetWorld()
	screen = cJson:Parse(fichier)
	construct(screen,World)
	charge({},Player)
	return true
end

function construct(screen,World)
	for i = 0,7,1 do
		for j = 7,0,-1 do
			World:SetBlock(pos["ecran"][1]-i,pos["ecran"][2],pos["ecran"][3]-j,0,0,true)
			if tonumber(screen["Payload"][i+1][j+1]) ~= 0 then
			World:SetBlock(pos["ecran"][1]-i,pos["ecran"][2],pos["ecran"][3]-j,35,tonumber(screen["Payload"][i+1][j+1])-1,true)
			end
			
			
		end
	end
	
	
	
	return true
end


function savescreen(Split, Player)
  
	tojson()
	file = io.open("screens/"..Split[2]..".json", "w")
	file:write(fichier)
	file:close()
	
	return true
end


function setrnd(Split,Player)
	if Split[2] == nil then
		Split[2] = "ecran"
	end
	
	liste[Split[2]] = {}
	World = Player:GetWorld()
	for i = pos[Split[2]][1],pos[Split[2]][4],-1 do
		for j = pos[Split[2]][6],pos[Split[2]][3],1 do
			World:SetBlock(i,pos[Split[2]][2],j,35, colors[math.random(1,13)],true)
		end
	end
	charge(Split, Player)
	return true
end

function charge(Split,Player)
	if Split[2] == nil then
		Split[2] = "ecran"
	end
	liste[Split[2]] = {}
	World = Player:GetWorld()
	for i = pos[Split[2]][1],pos[Split[2]][4],-1 do
		for j = pos[Split[2]][6],pos[Split[2]][3],1 do
			if World:GetBlock(i, pos[Split[2]][2],j) == 0 then
				table.insert(liste[Split[2]],0)
			else
				table.insert(liste[Split[2]],World:GetBlockMeta(i,pos[Split[2]][2],j)+1)
			end
			
		end
	end
	
	
	
	tojson(Split[2])
	send(fichier)
	return true
end

function tojson(screen)
fichier= "{ \"Type\": \"StaticId\",\n"
fichier= fichier.."\"Name\":\"all\",\n"
fichier= fichier.."\"Channel\":\"Minecraft\",\n"
fichier= fichier.."\"Payload\" : [\n"
local n = 1
	if screen == nil then
		screen = "ecran"
	end
	

	for i = 1,7,1 do
	fichier = fichier.."	["
		
		for j = 1,7,1 do
		
			fichier = fichier..liste[screen][n]..","
			n = n+1
		end
	
		fichier = fichier..liste[screen][n].."],\n"
		n=n+1
	end
	
	fichier = fichier.."	["

		for j = 1,7,1 do
	
			fichier = fichier..liste[screen][n]..","
			n = n+1
		end
	
		fichier = fichier..liste[screen][n].."]\n"
		n=n+1
	
	
	
	fichier = fichier.."]\n"
	fichier = fichier.."}"
	

	
	
	
	return true
end

function send(fichier)
local callbacks ={}	
	local headers ={}
	local options ={}
	
	cUrlClient:Post("http://"..address.."/display/", callbacks,headers, fichier, options)


return true
end


